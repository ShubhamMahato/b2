package com.b2.account.resource;

import com.b2.account.model.Order;
import com.b2.account.services.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/api/order")
public class OrderResource
{
    @Autowired
    OrderService orderService;

    @GetMapping("/getorders")
    private Object getOrderFromOrderHystrix(){
        Object obj=orderService.getAllOrders();
        return obj;
    }

}
