package com.b2.account.dao;

import com.b2.account.model.Address;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AddressDao extends MongoRepository<Address,Integer> {
}
