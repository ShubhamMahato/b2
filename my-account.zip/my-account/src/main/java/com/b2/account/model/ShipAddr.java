package com.b2.account.model;




import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "ShipAddr")
@TypeAlias("ShipAddr")
public class ShipAddr {

    @Id
    private Integer shipId;

    @Field("shipAddrId")
    private String shipAddrId;

    @Field("firstName")
    private String firstName;

    @Field("lastName")
    private String lastName;

    @Field("address")
    private String address;


    @Field("city")
    private String city;


    @Field("state")
    private String state;


    @Field("zip")
    private String zip;


    @Field("country")
    private String country;

    public Integer getShipId() {
        return shipId;
    }

    public void setShipId(Integer shipId) {
        this.shipId = shipId;
    }

    public String getShipAddrId() {
        return shipAddrId;
    }

    public void setShipAddrId(String shipAddrId) {
        this.shipAddrId = shipAddrId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public ShipAddr(Integer shipId, String shipAddrId, String firstName, String lastName, String address, String city, String state, String zip, String country) {
        this.shipId = shipId;
        this.shipAddrId = shipAddrId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.country = country;
    }

    public ShipAddr() {
    }

    @Override
    public String toString() {
        return "ShipAddr{" +
                "shipId=" + shipId +
                ", shipAddrId='" + shipAddrId + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", address='" + address + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", zip='" + zip + '\'' +
                ", country='" + country + '\'' +
                '}';
    }
}

