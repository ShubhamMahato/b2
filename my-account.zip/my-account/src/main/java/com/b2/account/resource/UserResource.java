package com.b2.account.resource;


import com.b2.account.dao.UserDao;
import com.b2.account.model.User;
import com.b2.account.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/user")
public class UserResource {

    @Autowired
     private UserService userService;


    @GetMapping("hello")
    public String hello(){
        return "Devansh";
    }
    public UserResource(UserService userService) {
        this.userService = userService;
    }

    @PostMapping(value="/create")
    public String newUser(@RequestBody User user) {
        return userService.addNewUser(user);
    }

    @GetMapping(value="/getuser")
    public List<User> getUser()
    {
        return userService.getAllUsers();
    }



}
