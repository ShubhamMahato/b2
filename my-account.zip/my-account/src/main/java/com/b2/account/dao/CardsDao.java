package com.b2.account.dao;

import com.b2.account.model.Cards;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CardsDao extends MongoRepository<Cards,Integer> {
}
