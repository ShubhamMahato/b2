package com.b2.account.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "LineItems")
@TypeAlias("LineItems")
public class LineItems {

    @Id
    private Integer lineItemId;

    @Field("productId")
    private String productId;


    @Field("skuId")
    private String skuId;

    @Field("categoryId")
    private String categoryId;

    @Field("productDesc")
    private String productDesc;

    @Field("displayName")
    private String displayName;

    @Field("orderedQty")
    private Integer orderedQty;

    @Field("unitCost")
    private Integer unitCost;

    public Integer getLineItemId() {
        return lineItemId;
    }

    public void setLineItemId(Integer lineItemId) {
        this.lineItemId = lineItemId;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getSkuId() {
        return skuId;
    }

    public void setSkuId(String skuId) {
        this.skuId = skuId;
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public Integer getOrderedQty() {
        return orderedQty;
    }

    public void setOrderedQty(Integer orderedQty) {
        this.orderedQty = orderedQty;
    }

    public Integer getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(Integer unitCost) {
        this.unitCost = unitCost;
    }

    public LineItems(Integer lineItemId, String productId, String skuId, String categoryId, String productDesc, String displayName, Integer orderedQty, Integer unitCost) {
        this.lineItemId = lineItemId;
        this.productId = productId;
        this.skuId = skuId;
        this.categoryId = categoryId;
        this.productDesc = productDesc;
        this.displayName = displayName;
        this.orderedQty = orderedQty;
        this.unitCost = unitCost;
    }

    public LineItems() {
    }

    @Override
    public String toString() {
        return "LineItems{" +
                "lineItemId=" + lineItemId +
                ", productId='" + productId + '\'' +
                ", skuId='" + skuId + '\'' +
                ", categoryId='" + categoryId + '\'' +
                ", productDesc='" + productDesc + '\'' +
                ", displayName='" + displayName + '\'' +
                ", orderedQty=" + orderedQty +
                ", unitCost=" + unitCost +
                '}';
    }
}
