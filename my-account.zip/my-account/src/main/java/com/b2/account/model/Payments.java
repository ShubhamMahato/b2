package com.b2.account.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.TypeAlias;
import org.springframework.data.mongodb.core.mapping.DBRef;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "Payments")
@TypeAlias("Payments")
public class Payments {
    @Id
    private Integer paymentId;

    @Field("id")
    private String id;

    @Field("amount")
    private Integer amount;


    @Field("type")
    private String type;

    @Field("cc")
    @JsonProperty("cc")

    private Cc cc;

    public Integer getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Integer paymentId) {
        this.paymentId = paymentId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Cc getCc() {
        return cc;
    }

    public void setCc(Cc cc) {
        this.cc = cc;
    }

    public Payments(Integer paymentId, String id, Integer amount, String type, Cc cc) {
        this.paymentId = paymentId;
        this.id = id;
        this.amount = amount;
        this.type = type;
        this.cc = cc;
    }

    public Payments() {
    }

    @Override
    public String toString() {
        return "Payments{" +
                "paymentId=" + paymentId +
                ", id='" + id + '\'' +
                ", amount=" + amount +
                ", type='" + type + '\'' +
                ", cc=" + cc +
                '}';
    }
}

