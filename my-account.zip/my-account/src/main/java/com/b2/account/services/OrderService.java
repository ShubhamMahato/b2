package com.b2.account.services;

import com.b2.account.model.Order;

import java.util.List;

public interface OrderService
{
    List<Order> getAllOrders();

    List<Order> getAllOrderForCustomer();
}
