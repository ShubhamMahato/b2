package com.b2.account.dao;

import com.b2.account.model.UserDetails;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UserDetailsDao extends MongoRepository<UserDetails,Integer> {
}
