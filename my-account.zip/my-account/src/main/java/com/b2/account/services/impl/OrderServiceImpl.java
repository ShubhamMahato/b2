package com.b2.account.services.impl;

import com.b2.account.model.Order;
import com.b2.account.services.OrderService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.xml.ws.Response;
import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {



    RestTemplate restTemplate = new RestTemplate();

    @HystrixCommand(fallbackMethod = "getFallBackCatalog")
    public List<Order> getAllOrders(){

        try{

            ResponseEntity<List<Order>> rateResponse = restTemplate.exchange("http://localhost:8222/api/order/getorders",
                            HttpMethod.GET, null, new ParameterizedTypeReference<List<Order>>() {
                            });
            List<Order> order = rateResponse.getBody();

            return order;
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return null;
    }

    @Override
    @HystrixCommand(fallbackMethod = "getAllOrderForCustomerCatalog")
    public List<Order> getAllOrderForCustomer() {
        try{

            ResponseEntity<List<Order>> rateResponse = restTemplate.exchange("http://localhost:8222/api/order/getorders",
                    HttpMethod.GET, null, new ParameterizedTypeReference<List<Order>>() {
                    });
            List<Order> order = rateResponse.getBody();

            return order;
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return null;
    }

    public List<Order> getFallBackCatalog()
    {

        return null;
    }
    public List<Order> getAllOrderForCustomerCatalog()
    {

        return null;
    }

}
